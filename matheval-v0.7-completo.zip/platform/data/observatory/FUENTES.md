# Fuentes y límites de los datos del observatorio

- **Oficiales (OCDE):** medias de matemática, lectura y ciencias de 2000 a 2022 por país, transcritas de PISA 2022 Results
  (Vol. I), Anexo D. Se omiten los ciclos sin dato («m» en la tabla): por ejemplo Argentina no tiene datos nacionales de 2015.
- **Secundarias (verificar):** el promedio de tendencia de la OCDE, todo lo de PISA 2025 y los porcentajes de estudiantes bajo el
  nivel 2. Cada fila lleva su fuente y su enlace.
- **Microdatos propios:** con `scripts/pisa_ingest.py` se agregan errores estándar y brechas calculados sobre los microdatos de la OCDE (calidad `microdatos_propios`). Ver `docs/MICRODATOS_PISA.md`.
- **Sin errores estándar:** esta tabla no trae errores estándar, así que no se declara significancia estadística. Para eso hay
  que usar las tablas oficiales de la OCDE (la tabla I.B1.5.4 y las del Anexo B1).
- **Comparabilidad:** Argentina pasó de prueba en papel a computadora en 2022; el promedio de la OCDE cambia de composición
  entre informes. Las diferencias de pocos puntos no son concluyentes.
- **Licencia:** revisar los términos de uso de la OCDE para cada publicación antes de redistribuir las tablas; citar siempre la fuente.
- **Ampliar:** agregar filas al CSV (mismo formato) y ejecutar `python scripts/validate_observatory.py`.
